.. _resources:

===========
 Resources
===========

.. contents::
    :local:
    :depth: 2

.. include:: ../includes/resources.txt
