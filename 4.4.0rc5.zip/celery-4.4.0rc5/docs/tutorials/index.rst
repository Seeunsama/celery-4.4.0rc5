===========
 Tutorials
===========

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    task-cookbook
