=====================================
 ``celery.backends.asynchronous``
=====================================

.. contents::
    :local:
.. currentmodule:: celery.backends.asynchronous

.. automodule:: celery.backends.asynchronous
    :members:
    :undoc-members:


