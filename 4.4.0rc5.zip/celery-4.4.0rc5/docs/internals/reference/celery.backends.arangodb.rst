============================================
 ``celery.backends.arangodb``
============================================

.. contents::
    :local:
.. currentmodule:: celery.backends.arangodb

.. automodule:: celery.backends.arangodb
    :members:
    :undoc-members:
