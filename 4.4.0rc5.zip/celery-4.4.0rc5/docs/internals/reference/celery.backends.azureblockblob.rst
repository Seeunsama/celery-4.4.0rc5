================================================
 ``celery.backends.azureblockblob``
================================================

.. contents::
    :local:
.. currentmodule:: celery.backends.azureblockblob

.. automodule:: celery.backends.azureblockblob
    :members:
    :undoc-members:
