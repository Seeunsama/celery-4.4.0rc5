============================================
 ``celery.backends.couchbase``
============================================

.. contents::
    :local:
.. currentmodule:: celery.backends.couchbase

.. automodule:: celery.backends.couchbase
    :members:
    :undoc-members:
