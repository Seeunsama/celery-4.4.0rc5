===========================================
 ``celery.backends.riak``
===========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.riak

.. automodule:: celery.backends.riak
    :members:
    :undoc-members:
