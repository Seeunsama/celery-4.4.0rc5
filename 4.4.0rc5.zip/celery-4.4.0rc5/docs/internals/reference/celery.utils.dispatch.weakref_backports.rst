====================================================
 ``celery.utils.dispatch.weakref_backports``
====================================================

.. contents::
    :local:
.. currentmodule:: celery.utils.dispatch.weakref_backports

.. automodule:: celery.utils.dispatch.weakref_backports
    :members:
    :undoc-members:
