==================================================
 ``celery.worker.consumer.heart``
==================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.consumer.heart

.. automodule:: celery.worker.consumer.heart
    :members:
    :undoc-members:
