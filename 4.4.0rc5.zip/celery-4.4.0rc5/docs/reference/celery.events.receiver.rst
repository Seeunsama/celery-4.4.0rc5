=================================================================
 ``celery.events.receiver``
=================================================================

.. contents::
    :local:
.. currentmodule:: celery.events.receiver

.. automodule:: celery.events.receiver
    :members:
    :undoc-members:
