====================================
 ``celery.contrib.testing.app``
====================================

.. contents::
    :local:

API Reference
=============

.. currentmodule:: celery.contrib.testing.app

.. automodule:: celery.contrib.testing.app
    :members:
    :undoc-members:

