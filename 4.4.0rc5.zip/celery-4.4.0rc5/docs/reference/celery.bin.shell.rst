=====================================================
 ``celery.bin.shell``
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.bin.shell

.. automodule:: celery.bin.shell
    :members:
    :undoc-members:
