====================================
 ``celery.contrib.testing.manager``
====================================

.. contents::
    :local:

API Reference
=============

.. currentmodule:: celery.contrib.testing.manager

.. automodule:: celery.contrib.testing.manager
    :members:
    :undoc-members:

