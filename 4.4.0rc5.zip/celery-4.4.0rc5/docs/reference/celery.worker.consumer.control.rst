==================================================
 ``celery.worker.consumer.control``
==================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.consumer.control

.. automodule:: celery.worker.consumer.control
    :members:
    :undoc-members:
