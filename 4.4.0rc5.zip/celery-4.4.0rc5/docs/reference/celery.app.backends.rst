===================================
 ``celery.app.backends``
===================================

.. contents::
    :local:
.. currentmodule:: celery.app.backends

.. automodule:: celery.app.backends
    :members:
    :undoc-members:
